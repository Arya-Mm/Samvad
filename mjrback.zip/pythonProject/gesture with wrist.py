import cv2
import mediapipe as mp
from cvzone.HandTrackingModule import HandDetector
import cvzone

cap = cv2.VideoCapture(0)

detector = HandDetector(maxHands=1, detectionCon=round(0.7))  # Round the float value to the nearest integer
mySerial = cvzone.SerialObjectArduino("COM4", 9600, 1)  # Use SerialObjectArduino for Arduino communication

while True:
    success, img = cap.read()
    img = detector.findHands(img)
    lmList, bbox = detector.findPosition(img)
    if lmList:
        # Add wrist position to the list of finger positions
        wrist_x = lmList[0][0]
        wrist_y = lmList[0][1]
        fingers = detector.fingersUp(lmList)
        fingers.append((wrist_x, wrist_y))
        print(fingers)
        mySerial.sendData(fingers)
    cv2.imshow("Image", img)
    cv2.waitKey(1)