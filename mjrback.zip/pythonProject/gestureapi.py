from flask import Flask, request
import cv2
import cvzone

app = Flask(__name__)
cap = cv2.VideoCapture(0)
detector = cvzone.HandDetector(maxHands=1, detectionCon=0.7)
mySerial = cvzone.SerialObjectArduino("COM4", 9600, 1)

@app.route('/receive-hand-data', methods=['POST'])
def receive_hand_data():
    data = request.json
    fingers = data['fingers']
    mySerial.sendData(fingers)
    return 'Data received and sent to Arduino'

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
