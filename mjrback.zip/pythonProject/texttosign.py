import cvzone
import cv2

cap = cv2.VideoCapture(0)  # Use 0 for the first webcam
detector = cvzone.HandDetector(maxHands=1, detectionCon=0.7)
mySerial = cvzone.SerialObjectArduino("COM4", 9600, 1)  # Use SerialObjectArduino for Arduino communication

while True:
    success, img = cap.read()
    img = cv2.flip(img, 1)  # Flip the image horizontally for a more natural view
    img = detector.findHands(img)
    lmList, _ = detector.findPosition(img)

    if lmList:
        # Get the gesture for each finger
        thumbGesture = detector.fingerUp(lmList, 4)
        indexGesture = detector.fingerUp(lmList, 8)
        middleGesture = detector.fingerUp(lmList, 12)
        ringGesture = detector.fingerUp(lmList, 16)
        pinkyGesture = detector.fingerUp(lmList, 20)

        # Define the gestures for each letter or number
        gestures = {
            'A': [1, 0, 0, 0, 0], 'B': [1, 1, 0, 0, 0], 'C': [1, 1, 1, 0, 0],
            'D': [1, 1, 1, 1, 0], 'E': [1, 1, 1, 1, 1],
            '1': [0, 0, 0, 0, 1], '2': [0, 0, 0, 1, 1], '3': [0, 0, 1, 1, 1],
            '4': [0, 1, 1, 1, 1], '5': [1, 1, 1, 1, 1]
        }

        # Send the corresponding gesture to the servos based on user input
        letter = input("Enter a letter (A-E): ")
        if letter.upper() in gestures:
            gesture = gestures[letter.upper()]
            for key, value in gestures.items():
                if gesture == value:
                    print("Detected gesture:", key)
                    mySerial.sendData(key)
                    break

    cv2.imshow("Image", img)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()