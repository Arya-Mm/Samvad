from flask import Flask, request
import cv2
import cvzone

app = Flask(__name__)
cap = cv2.VideoCapture(0)
detector = cvzone.HandDetector(maxHands=1, detectionCon=0.7)
mySerial = cvzone.SerialObjectArduino("COM4", 9600, 1)

@app.route('/send-letter', methods=['POST'])
def send_letter():
    data = request.json
    letter = data['letter']
    gestures = {
        'A': [1, 0, 0, 0, 0], 'B': [1, 1, 0, 0, 0], 'C': [1, 1, 1, 0, 0],
        'D': [1, 1, 1, 1, 0], 'E': [1, 1, 1, 1, 1],
        '1': [0, 0, 0, 0, 1], '2': [0, 0, 0, 1, 1], '3': [0, 0, 1, 1, 1],
        '4': [0, 1, 1, 1, 1], '5': [1, 1, 1, 1, 1]
    }
    if letter.upper() in gestures:
        gesture = gestures[letter.upper()]
        for key, value in gestures.items():
            if gesture == value:
                print("Detected gesture:", key)
                mySerial.sendData(key)
                break
    return 'Letter received and gesture sent to Arduino'

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
