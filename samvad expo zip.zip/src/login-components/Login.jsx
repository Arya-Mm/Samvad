// Login.js

import React, { useState } from 'react';
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css';

const Login = ({ onLogin }) => {

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = () => {
    // You can replace this with your authentication logic
    if (username === 'Rugved' && password === 'DRAGO&99') {
      // Successful login, navigate to the next page
      onLogin();
      navigate('/dashboard');
    } else {
      // Failed login, display error message
      setError('Invalid username or password');
    }
  }

  useEffect(() => {
    const container = document.getElementById('container');
    const registerBtn = document.getElementById('register');
    const loginBtn = document.getElementById('login');

    if (registerBtn && loginBtn) {
      registerBtn.addEventListener('click', () => {
        container.classList.add("active");
      });

      loginBtn.addEventListener('click', () => {
        container.classList.remove("active");
      });
    }
  }, []);

  return (
    <div className='login-super-container'>
      <div className="container" id="container">
        <div className="form-container sign-up">
          <form>
            <h1>Create Account</h1>
            <div className="social-icons">
              <a href="#" className="icon"><i className="fa-brands fa-google-plus-g"></i></a>
              <a href="#" className="icon"><i className="fa-brands fa-facebook-f"></i></a>
              <a href="#" className="icon"><i className="fa-brands fa-github"></i></a>
              <a href="#" className="icon"><i className="fa-brands fa-linkedin-in"></i></a>
            </div>
            <span>or use your email for registeration</span>
            <input type="text" placeholder="Name" id="username" value={username} onChange={(e) => setUsername(e.target.value)} />
            <input type="email" placeholder="Email" />
            <input type="password" placeholder="Password" id="password" value={password} onChange={(e) => setPassword(e.target.value)} />
            <button onClick={handleLogin}>Sign Up</button>
          </form>
        </div>
        <div className="form-container sign-in">
          <form>
            <h1>Sign In</h1>
            <div className="social-icons">
              <a href="#" className="icon"><i className="fa-brands fa-google-plus-g"></i></a>
              <a href="#" className="icon"><i className="fa-brands fa-facebook-f"></i></a>
              <a href="#" className="icon"><i className="fa-brands fa-github"></i></a>
              <a href="#" className="icon"><i className="fa-brands fa-linkedin-in"></i></a>
            </div>
            <span>or use your email password</span>
            <input type="text" placeholder="Name" id="username" value={username} onChange={(e) => setUsername(e.target.value)} />
            {/* <input type="email" placeholder="Email" /> */}
            <input type="password" placeholder="Password" id="password" value={password} onChange={(e) => setPassword(e.target.value)} />
            <a href="#">Forget Your Password?</a>
            <button onClick={handleLogin}>Sign In</button>
          </form>
        </div>
        <div className="toggle-container">
          <div className="toggle">
            <div className="toggle-panel toggle-left">
              <h1>Welcome Back!</h1>
              <p>Enter your personal details to use all of site features</p>
              <button className="hidden" id="login">Sign In</button>
              <img className="rsz-1wepik-export-202310101419-icon" alt="" src="C:\Users\Harsh Lad\Downloads\Screenshot_2024-01-07_202707-removebg-preview (1).png" />

            </div>
            <div className="toggle-panel toggle-right">
              <h1>Hello, Friend!</h1>
              <p>Register with your personal details to use all of site features</p>
              <button className="hidden" id="register">Sign Up</button>
              <img className="rightimg" alt="" src="C:\Users\Harsh Lad\OneDrive\Desktop\Screenshot_2024-01-07_202707-removebg-preview (2).png" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;

// const Login = () => {
//   const [username, setUsername] = useState('');
//   const [password, setPassword] = useState('');
//   const [error, setError] = useState('');
//   const navigate = useNavigate(); // Use useNavigate instead of useHistory

//   const handleLogin = () => {
//     // You can replace this with your authentication logic
//     if (username === 'Rugved' && password === 'DRAGO&99') {
//       // Successful login, navigate to the next page
//       navigate('/dashboard');
//     } else {
//       // Failed login, display error message
//       setError('Invalid username or password');
//     }
//   };

//   return (
//     <div className="login-container">
//       <h2>Login</h2>
//       <div className="login-form">
//         <label htmlFor="username">Username:</label>
//         <input
//           type="text"
//           id="username"
//           value={username}
//           onChange={(e) => setUsername(e.target.value)}
//         />

//         <label htmlFor="password">Password:</label>
//         <input
//           type="password"
//           id="password"
//           value={password}
//           onChange={(e) => setPassword(e.target.value)}
//         />

//         <button onClick={handleLogin}>Login</button>

//         {error && <p className="error-message">{error}</p>}
//       </div>
//     </div>
//   );
// };

// export default Login;


// import React, { useState } from 'react';
// import './Login.css'; // Import your stylesheet here

// const Login = () => {
//   return (
//     <div className="container" id="container">
//       <div className="form-container sign-up">
//         <form>
//           <h1>Create Account</h1>
//           <div className="social-icons">
//             <a href="#" className="icon"><i className="fab fa-google-plus-g"></i></a>
//             <a href="#" className="icon"><i className="fab fa-facebook-f"></i></a>
//             <a href="#" className="icon"><i className="fab fa-github"></i></a>
//             <a href="#" className="icon"><i className="fab fa-linkedin-in"></i></a>
//           </div>
//           <span>or use your email for registration</span>
//           <input type="text" placeholder="Name" />
//           <input type="email" placeholder="Email" />
//           <input type="password" placeholder="Password" />
//           <button>Sign Up</button>
//         </form>
//       </div>
//       <div className="form-container sign-in">
//         <form>
//           <h1>Sign In</h1>
//           <div className="social-icons">
//             <a href="#" className="icon"><i className="fab fa-google-plus-g"></i></a>
//             <a href="#" className="icon"><i className="fab fa-facebook-f"></i></a>
//             <a href="#" className="icon"><i className="fab fa-github"></i></a>
//             <a href="#" className="icon"><i className="fab fa-linkedin-in"></i></a>
//           </div>
//           <span>or use your email password</span>
//           <input type="email" placeholder="Email" />
//           <input type="password" placeholder="Password" />
//           <a href="#">Forget Your Password?</a>
//           <button>Sign In</button>
//         </form>
//       </div>
//       <div className="toggle-container">
//         <div className="toggle">
//           <div className="toggle-panel toggle-left">
//             <h1>Welcome Back!</h1>
//             <p>Enter your personal details to use all site features</p>
//             <button className="hidden" id="login">Sign In</button>
//             <img className="rsz-1wepik-export-202310101419-icon" alt="" src="./images/left.png" />
//           </div>
//           <div className="toggle-panel toggle-right">
//             <h1>Hello, Friend!</h1>
//             <p>Register with your personal details to use all site features</p>
//             <button className="hidden" id="register">Sign Up</button>
//             <img className="rightimg" alt="" src="./images/right.png" />
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Login;