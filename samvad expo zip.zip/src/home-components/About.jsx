import './home.css';
import '../dsahboard-components/oprations.css';
import close from "../../src/assets/images/close-button.png";
import { useNavigate } from 'react-router-dom';
const About = () => {
    const navigate = useNavigate();
    const handleHome = () =>{
        navigate('/');
    }
    return ( 
        <div className='main-about'>
            About us!
            <img
            src={close}
            alt=""
            height="35px"
            width="35px"
            className="exit-button"
            onClick={handleHome}
            />
        </div>
     );
}
 
export default About;