import React from 'react';
import { useNavigate } from 'react-router-dom';
import logo from "../../src/assets/images/purple-logo-mini.jpg";

const Nav = () => {
  const navigate = useNavigate();
  const handleLoginClick = () => {
    // Redirect to your desired component or route
    navigate('/login');
  };

  const handleAbout = () =>{
    navigate('/about');
  }

  const handleServies = () =>{
    navigate('/service');
  }

  const handleHome = () =>{
    navigate('/');
  }

  return (
    <nav className="nav-wrapper">
      <div className="nav-content">
        <ul className="list-styled">
          <img src={logo} height="35px" width="35px" className="logo" />
          <li className="link-styled" onClick={handleHome}>Home</li>
          <li className="link-styled" onClick={handleAbout}>About</li>
          <li className="link-styled" onClick={handleServies}>Services</li>
          <li className="link-styled"><button className='login-button' onClick={handleLoginClick} >Login</button></li>
        </ul>
      </div>
    </nav>
  );
};

export default Nav;
