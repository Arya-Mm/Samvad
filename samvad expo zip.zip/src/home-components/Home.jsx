import Nav from './Nav';
import './home.css'

function Home() {

  return (
    <div className="App">
      <div id="content">
        <Nav />
      </div>
    </div>
  );
}

export default Home;

