import React, { useState } from "react";
import { Routes, Route, BrowserRouter as Router, Navigate } from 'react-router-dom';
import Home from "./home-components/Home";
import About from "./home-components/About";
import Dashboard from "./dsahboard-components/Dashboard";
import Login from "./login-components/Login";
import Services from "./home-components/Services";

function App() {
  const [isAuthenticated, setAuthenticated] = useState(false);

  const handleLogin = () => {
    // Your authentication logic goes here
    // Set isAuthenticated to true upon successful login
    setAuthenticated(true);
  };

  const handleLogout = () => {
    // Handle logout logic
    setAuthenticated(false);
  };

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login onLogin={handleLogin} />} />
        <Route path="/about" element={<About/>}/>
        <Route path="/service" element={<Services/>}/>
        <Route
          path="/dashboard"
          element={isAuthenticated ? <Dashboard /> : <Navigate to="/login" />}
        />
      </Routes>
    </Router>
  );
}

export default App;