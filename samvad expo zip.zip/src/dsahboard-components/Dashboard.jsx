//Dashboard.jsx
import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import './global.css';
import './dashbord.css';
import './oprations.css';
import { selectMode, passMessage, exitOpration, openCamera, updateOprationTextValue, storeOprationState, restoreRecent, removeRecent, } from '../../src/assets/lib/DashboardSlice';
import logo from "../../src/assets/images/purple-logo.jpg";
import close from "../../src/assets/images/close-button.png";
import one from "../../src/assets/images/one.png";
import two from "../../src/assets/images/two.jpg";
import three from "../../src/assets/images/three.jpg";
import remove from "../../src/assets/images/delete-icon.jpg";

function Dashboard() {
    const dispatch = useDispatch();
    const {
        oprationTitle,
        oprationTextDisabled,
        oprationMessageBox,
        oprationImgSrc,
        cardsStyle,
        recentsStyle,
        navStyle,
        oprationStyle,
        oprationCamera,
        oprationNav,
        promptBox,
        oprationTextValue,
        oprationTextPlaceholder,
        videoDataURL,
        cameraError,
    } = useSelector((state) => state.dashboard);

    const recentsQueue = useSelector((state) => state.dashboard.recentsQueue);
    return (
        <div className="parent">
            <div className="center">
                <div className="nav" style={navStyle}>
                    <div className="opration" style={oprationStyle}>
                        <div className="opration-nav" style={oprationNav}>
                            <img src={logo} height="35px" width="35px" className="logo" />
                            <div id="mode-heading">{oprationTitle}</div>
                            <img
                                src={close}
                                alt=""
                                height="35px"
                                width="35px"
                                className="exit-button"
                                onClick={() => {
                                    dispatch(storeOprationState());
                                    dispatch(exitOpration());
                                }}
                            />
                        </div>

                        <div className="opration-message-box" style={oprationMessageBox}>
                            {oprationMessageBox && oprationMessageBox.messages && oprationMessageBox.messages.map((message, index) => (
                                <div key={index} className="opration-message">
                                    {message}
                                </div>
                            ))}
                        </div>

                        <div className="opration-camera" style={oprationCamera}>
                            {videoDataURL && (
                                <video
                                    ref={(videoRef) => {
                                        if (videoRef) videoRef.srcObject = videoDataURL;
                                    }}
                                    autoPlay
                                    style={{ width: '100%', height: '100%' }}
                                ></video>
                            )}
                            {cameraError && <div>{cameraError}</div>}
                        </div>

                        <div className="promptBox" style={promptBox}>
                            <textarea
                                className="opration-text"
                                placeholder={oprationTextPlaceholder}
                                disabled={oprationTextDisabled}
                                value={oprationTextValue}
                                onChange={(e) => dispatch(updateOprationTextValue(e.target.value))}
                            ></textarea>

                            <div
                                className="prompt-icon"
                                onClick={() => {
                                    if (oprationTitle === 'Gesture Mode') {
                                        dispatch(openCamera);
                                    } else if (oprationTitle === 'Text to Gesture Mode') {
                                        dispatch(passMessage(oprationTextValue));
                                    } else {
                                        dispatch(openMic);
                                    }
                                }}
                            >
                                <img id="opration-img" src={oprationImgSrc} height="40px" width="40px" />
                            </div>

                        </div>
                    </div>
                </div>
                <div className="cards" style={cardsStyle}>
                    <div className="heading">Options To Select</div>
                    <div className="card-collect">
                        <div className="card" onClick={() => {
                            dispatch(selectMode({ oprationTitle: 'Gesture Mode' }));
                        }}
                        >
                            <img className="card-img" src={one} alt="" height="48%" width="98%" />
                            <div className="card-description">
                                <div className="description-title">Gesture Mode</div>
                            </div>
                        </div>
                        <div
                            className="card"
                            onClick={() => {
                                dispatch(selectMode({ oprationTitle: 'Text to Gesture Mode' }));
                            }}
                        >
                            <img className="card-img" src={two} alt="" height="48%" width="98%" />
                            <div className="card-description">
                                <div className="description-title">Text to Gesture Mode</div>
                            </div>
                        </div>
                        <div
                            className="card"
                            onClick={() => {
                                dispatch(selectMode({ oprationTitle: 'Speech to Gesture Mode' }));
                            }}
                        >
                            <img className="card-img" src={three} alt="" height="48%" width="98%" />
                            <div className="card-description">
                                <div className="description-title">Speech to Gesture Mode</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="recents" style={recentsStyle}>
                    <div className="heading">History</div>
                    <div className="recent-collect">
                        {recentsQueue.map((recent, index) => (
                            <div className="recent" onClick={() => {
                                dispatch(restoreRecent(recent));
                            }}>
                                <img className="recent-img" src={logo} alt="" />
                                <div className="recent-description" onClick={(e) => {
                                    e.stopPropagation(); // Stop event propagation
                                    dispatch(selectMode({ oprationTitle: recent.oprationTitle }));
                                }}>
                                    <div className="description-title">{recent.oprationTitle}</div>
                                    <div>Duration: 4min</div>
                                </div>
                                <img className="recent-img" src={remove} alt="" onClick={() => dispatch(removeRecent(index))} />
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;