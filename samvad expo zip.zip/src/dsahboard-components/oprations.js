// Decrease the height and width of the clicked card

function selectMode(element) {
  var cards = document.querySelector('.cards');
  var recents = document.querySelector('.recents');
  var nav = document.querySelector('.nav');
  var opration = document.querySelector('.opration');

  cards.style.height = '0%';
  cards.style.width = '0%';
  cards.style.opacity = '0';

  recents.style.height = '0%';
  recents.style.width = '0%';
  recents.style.opacity = '0';

  nav.style.height = '100%';
  nav.style.width = '100%';

  opration.style.width = '98%';
  opration.style.height = '98%';
  opration.style.borderRadius = '15px';

  // Get the text from the description-title of the clicked card
  var oprationTitle = element.querySelector('.description-title').textContent;

  if (oprationTitle == 'Gesture Mode') {
    manageGesture(oprationTitle);
  } else if (oprationTitle == 'Text to Speech Mode') {
    manageTextToSpeech(oprationTitle);
  } else {
    manageSpeechToText(oprationTitle);
  }
}

function passMessage() {
  var text = document.querySelector('.opration-text').value;
  var messagePlace = document.querySelector('.opration-message-box');
  messagePlace.innerHTML += "<div class='opration-message'>" + text + "</div>";
  document.querySelector('.opration-text').value = "";
}

function exitOpration() {
  invisibleElements();

  var cards = document.querySelector('.cards');
  var recents = document.querySelector('.recents');
  var nav = document.querySelector('.nav');
  var opration = document.querySelector('.opration');

  cards.style.height = '45%';
  cards.style.width = '90%';
  cards.style.opacity = '1';

  recents.style.height = '45%';
  recents.style.width = '90%';
  recents.style.opacity = '1';

  nav.style.height = '7.5%';
  nav.style.width = '90%';

  opration.style.width = '25%';
  opration.style.height = '50%';
  opration.style.borderRadius = 'var(--br-81xl)';

}

function invisibleElements() {
  document.querySelector('.opration-nav').style.opacity = '0';
  document.querySelector('.opration-message-box').style.opacity = '0';
  document.querySelector('.opration-camera').style.opacity = '0';
  document.querySelector('.promptBox').style.opacity = '0';
}

function visibleElements(oprationTitle) {
  var modeHeading = document.getElementById('mode-heading');
  modeHeading.textContent = oprationTitle;
  document.querySelector('.opration-nav').style.opacity = '1';
  document.querySelector('.opration-message-box').style.opacity = '1';
  document.querySelector('.opration-camera').style.opacity = '1';
  document.querySelector('.promptBox').style.opacity = '1';
}

function manageGesture(oprationTitle) {
  console.log('manageGesture');
  visibleElements(oprationTitle);
  document.querySelector('.opration-message-box').style.opacity = '0';
  document.querySelector('.opration-message-box').style.height = '0%';
  document.querySelector('.opration-message-box').style.width = '0%';

  document.querySelector('.opration-camera').style.height = "55%";
  document.querySelector('.opration-camera').style.width = '70%';
  document.querySelector('.opration-camera').style.border = '2px solid var(--color-khaki)';
  document.querySelector('.opration-text').disabled = false;
  document.querySelector('.opration-text').placeholder = "Open Camera to Gesture!";
  document.getElementById('opration-img').src = "./assets/images/camera-icon.jpg";
}

function manageTextToSpeech(oprationTitle) {
  console.log('manageTextToSpeech');
  visibleElements(oprationTitle);
  document.querySelector('.opration-message-box').style.opacity = '1';
  document.querySelector('.opration-message-box').style.height = '55%';
  document.querySelector('.opration-message-box').style.width = '70%';

  document.querySelector('.opration-camera').style.height = '0%';
  document.querySelector('.opration-camera').style.width = '0%';
  document.querySelector('.opration-camera').style.border = 'transparent';

  document.querySelector('.opration-text').disabled = false;
  document.querySelector('.opration-text').placeholder = "Type here...!";
  document.getElementById('opration-img').src = "./assets/images/send-icon.png";
}

function manageSpeechToText(oprationTitle) {
  console.log('manageSpeechToText');
  visibleElements(oprationTitle);
  document.querySelector('.opration-message-box').style.opacity = '1';
  document.querySelector('.opration-message-box').style.height = '55%';
  document.querySelector('.opration-message-box').style.width = '70%';

  document.querySelector('.opration-camera').style.height = '0%';
  document.querySelector('.opration-camera').style.width = '0%';
  document.querySelector('.opration-camera').style.border = 'transparent';

  document.querySelector('.opration-text').disabled = true;
  document.querySelector('.opration-text').placeholder = "Click on Mic!";
  document.getElementById('opration-img').src = "./assets/images/mic-icon.jpg";
}