package com.example.dailyplanner;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

import static com.example.dailyplanner.LogInActivity.userID;

public class NewNoteActivity extends AppCompatActivity {

    private Button setNoteButton,saveNoteButton,cancel,view,back;
    private EditText note,setNoteName;
    private TextView noteName;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference dref;
    private ProgressDialog progressDialog;
    public static String sendNoteName;
    public static NewNote snote;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_note_acitivity);
        Toolbar toolbar = findViewById(R.id.too_bar);
        setSupportActionBar(toolbar);
        toolbar.setTitleTextAppearance(this, R.style.CustomToolbarStyle);
        bindWidgets();
        bindListeners();
    }
    private void bindWidgets(){
        setNoteButton=findViewById(R.id.set_note_button);
        saveNoteButton=findViewById(R.id.save_note_button);
        cancel=findViewById(R.id.cancel_note);
        note=findViewById(R.id.note);
        setNoteName=findViewById(R.id.set_note_name);
        noteName=findViewById(R.id.note_name);
        dref= FirebaseDatabase.getInstance().getReference();
        progressDialog=new ProgressDialog(this);
        view=findViewById(R.id.view);
        back=findViewById(R.id.backtonotes);
        firebaseAuth=FirebaseAuth.getInstance();
    }

    private void bindListeners(){
        setNoteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameOfNote =setNoteName.getText().toString();
                if(nameOfNote.isEmpty()){
                    Toast.makeText(NewNoteActivity.this,"Enter a note name",Toast.LENGTH_LONG).show();
                    return;
                }
                noteName.setText(nameOfNote);
                noteName.setVisibility(View.VISIBLE);
                setNoteButton.setVisibility(View.INVISIBLE);
                setNoteName.setVisibility(View.INVISIBLE);
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(NewNoteActivity.this,NotesActivity.class));
            }
        });
        saveNoteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String noteName = setNoteName.getText().toString().trim();
                String noteContent=note.getText().toString();
                NewNote userNote = new NewNote(noteName,noteContent);
                sendNoteName=noteName;
                progressDialog.setTitle("Saving");
                progressDialog.show();
                dref.child(userID).child("Notes").child(noteName+userID).setValue(userNote).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        progressDialog.dismiss();
                        Toast.makeText(NewNoteActivity.this,"Success",Toast.LENGTH_LONG).show();






                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        progressDialog.dismiss();
                        Toast.makeText(NewNoteActivity.this,"Failed",Toast.LENGTH_LONG).show();
                    }
                });

                dref.child(userID).child("Notes").child(noteName+userID).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()){
                            System.out.println(dataSnapshot.getValue());
                            HashMap<String, Object> dataMap = (HashMap<String, Object>) dataSnapshot.getValue();
                            NewNote abs = new NewNote((String)dataMap.get("name"), (String) dataMap.get("content"));
                            System.out.println(abs.name+"        "+abs.content);
                            snote=new NewNote(abs.name,abs.content);
                            System.out.println(snote.name+"     "+snote.content);


                        }
                        else{
                            System.out.println("Failed");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });


            }
        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(NewNoteActivity.this,SuccessfulNote.class));
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                noteName.setText("");
                noteName.setVisibility(View.INVISIBLE);
                setNoteName.setText("");
                setNoteName.setVisibility(View.VISIBLE);
                setNoteButton.setVisibility(View.VISIBLE);
                note.setText("");
            }
        });
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(NewNoteActivity.this, NotesActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();

    }

}
