from flask import Flask, jsonify, send_file
from flask_cors import CORS
import cv2
import mediapipe as mp
from cvzone.HandTrackingModule import HandDetector
import cvzone
import base64
import os
import tempfile

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

@app.route('/hand-data', methods=['GET'])
def get_hand_data():
    cap = cv2.VideoCapture(0)
    detector = HandDetector(maxHands=1, detectionCon=round(0.7))
    mySerial = cvzone.SerialObject("COM6", 9600, 1)

    success, img = cap.read()
    img = detector.findHands(img)
    lmList, bbox = detector.findPosition(img)
    if lmList:
        fingers = detector.fingersUp()
        print(fingers)
        _, img_encoded = cv2.imencode('.jpg', img)
        img_data = base64.b64encode(img_encoded).decode('utf-8')
        return jsonify({'fingers': fingers, 'img': img_data})
    else:
        return jsonify({'fingers': [], 'img': None})

if __name__ == '__main__':
    app.run(debug=True)