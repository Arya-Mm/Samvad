import cvzone
import cv2
import speech_recognition as sr
from cvzone.HandTrackingModule import HandDetector
import cvzone

# Initialize the serial communication with the Arduino board
mySerial = cvzone.SerialObject("COM6" , 9600 , 1)

# Define gestures for letters (A-E) and numbers (1-5)
gestures = {
    'A': [1, 0, 0, 0, 0], 'B': [1, 1, 0, 0, 0], 'C': [1, 1, 1, 0, 0],
    'D': [1, 1, 1, 1, 0], 'E': [1, 1, 1, 1, 1],
    '1': [0, 0, 0, 0, 1], '2': [0, 0, 0, 1, 1], '3': [0, 0, 1, 1, 1],
    '4': [0, 1, 1, 1, 1], '5': [1, 1, 1, 1, 1]
}

# Initialize the speech recognizer
recognizer = sr.Recognizer()

while True:
    try:
        with sr.Microphone() as source:
            print("Speak a letter (A-E) or a number (1-5):")
            audio = recognizer.listen(source)

        # Recognize the speech
        letter = recognizer.recognize_google(audio).upper()

        if letter in gestures:
            gesture = gestures[letter]
            for key, value in gestures.items():
                if gesture == value:
                    print("Detected gesture:", key)
                    mySerial.sendData(key)
                    break

    except sr.UnknownValueError:
        print("Speech Recognition could not understand audio")
    except sr.RequestError as e:
        print("Could not request results from Google Speech Recognition service; {0}".format(e))