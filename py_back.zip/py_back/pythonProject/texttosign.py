import serial

# Initialize the serial communication object
try:
    mySerial = serial.Serial('COM6', 9600)
except serial.SerialException as e:
    print("Failed to open serial port:", e)
    exit()

# Define the gestures dictionary
gestures = {
    'A': [1, 0, 0, 0, 0], 'B': [0, 1, 1, 1, 1], 'F': [0, 0, 1, 1, 1],
    'D': [0, 1, 0, 0, 0], 'E': [0, 0, 0, 0, 0],
    '1': [0, 1, 0, 0, 0], '2': [0, 1, 1, 0, 0], '3': [0, 1, 1, 1, 0],
    '4': [0, 1, 1, 1, 1], '5': [1, 1, 1, 1, 1]
}

# Continuously listen for keyboard input
try:
    while True:
        # Prompt the user to enter a letter (A-E)
        letter = input("Enter a letter (A,b,d,e,f) or a number (1-5), or 'q' to quit: ")

        # Check if the user wants to quit
        if letter.lower() == 'q':
            break

        # Check if the entered letter is valid
        if letter.upper() in gestures:
            gesture = gestures[letter.upper()]
            print("Detected gesture:", letter.upper())

            # Send the gesture code to Arduino
            gesture_code = '$' + ''.join(str(bit) for bit in gesture) + '$'
            mySerial.write(gesture_code.encode())
        else:
            print("Invalid input. Please enter a letter from A to E or a number from 1 to 5.")

finally:
    # Close the serial connection
    mySerial.close()
