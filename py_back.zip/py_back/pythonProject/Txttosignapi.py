from flask import Flask, request, jsonify
import serial

app = Flask(__name__)
mySerial = None


# Initialize the serial communication object
def initialize_serial():
    global mySerial
    try:
        mySerial = serial.Serial('COM6', 9600)
    except serial.SerialException as e:
        return str(e)
    return "Serial port opened successfully"


# Close the serial connection
def close_serial():
    global mySerial
    if mySerial:
        mySerial.close()
        return "Serial port closed successfully"
    return "Serial port was not open"


# Define the gestures dictionary
gestures = {
    'A': [1, 0, 0, 0, 0], 'B': [0, 1, 1, 1, 1], 'C': [1, 1, 1, 0, 0],
    'D': [0, 0, 0, 1, 0], 'E': [0, 0, 0, 0, 0],
    '1': [0, 1, 0, 0, 0], '2': [0, 1, 1, 0, 0], '3': [0, 1, 1, 1, 0],
    '4': [0, 1, 1, 1, 1], '5': [1, 1, 1, 1, 1]
}


# Send gesture code to Arduino
def send_gesture(gesture):
    global mySerial
    if mySerial:
        if gesture.upper() in gestures:
            gesture_code = '$' + ''.join(str(bit) for bit in gestures[gesture.upper()]) + '$'
            mySerial.write(gesture_code.encode())
            return f"Sent gesture: {gesture.upper()}"
        else:
            return "Invalid gesture"
    else:
        return "Serial port is not open"


# API endpoint to open serial port
@app.route('/open', methods=['POST'])
def open_serial():
    return initialize_serial()


# API endpoint to close serial port
@app.route('/close', methods=['POST'])
def close_serial_port():
    return close_serial()


# API endpoint to send gesture
@app.route('/gesture', methods=['POST'])
def send_gesture_to_arduino():
    data = request.get_json()
    gesture = data.get('gesture')
    return send_gesture(gesture)


if __name__ == '__main__':
    app.run(debug=True)
