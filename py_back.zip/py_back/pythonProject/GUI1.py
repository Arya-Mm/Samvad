import serial
import tkinter as tk

# Initialize the serial communication object
try:
    mySerial = serial.Serial('COM6', 9600)
except serial.SerialException as e:
    print("Failed to open serial port:", e)
    exit()

# Define the gestures dictionary
gestures = {
    'A': [1, 0, 0, 0, 0], 'B': [0, 1, 1, 1, 1], 'C': [1, 1, 1, 0, 0],
    'D': [0, 0, 0, 1, 0], 'E': [0, 0, 0, 0, 0],
    '1': [0, 1, 0, 0, 0], '2': [0, 1, 1, 0, 0], '3': [0, 1, 1, 1, 0],
    '4': [0, 1, 1, 1, 1], '5': [1, 1, 1, 1, 1]
}

# Function to send gesture to Arduino
def send_gesture(letter):
    if letter.upper() in gestures:
        gesture = gestures[letter.upper()]
        print("Detected gesture:", letter.upper())

        # Send the gesture code to Arduino
        gesture_code = '$' + ''.join(str(bit) for bit in gesture) + '$'
        mySerial.write(gesture_code.encode())
    else:
        print("Invalid input. Please enter a letter from A to E or a number from 1 to 5.")

# Create a GUI window
window = tk.Tk()
window.title("Gesture Sender")

# Function to handle button click
def button_click(letter):
    send_gesture(letter)

# Create buttons for each gesture
for letter in gestures.keys():
    btn = tk.Button(window, text=letter, command=lambda l=letter: button_click(l))
    btn.pack()

# Function to handle quit
def quit():
    window.destroy()
    mySerial.close()

# Create a quit button
quit_btn = tk.Button(window, text="Quit", command=quit)
quit_btn.pack()

# Run the GUI main loop
window.mainloop()
